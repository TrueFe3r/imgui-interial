#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "includes/Dobby/dobby.h"
#include "Color.h"
#include "Includes/Macros.h"
#include "imgui.h"
#include "box_shadow.cpp"
#include "imgui_internal.h"
#include "Bools_Hooks.h"
#include "Chams.h"

#include "PostProcessing.h"

#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"
#define targetLibName OBFUSCATE("libil2cpp.so")
#define libNames OBFUSCATE("libil2cpp.so")
#include "ByNameModding/BNM.hpp"
using namespace BNM;
int glHeight, glWidth;
bool setup;
uintptr_t address;

bool page1 = true;
bool page2 = false;
bool page3 = false;
bool page4 = false;
bool page5 = false;

float scaleEz = 1.5f;

bool openMenuuuu = true;
bool lastopenmenu = false;

bool test1, test2, test3 = false;

bool flCheck = false;
bool clCheck = false;

bool abanCheck = false;
bool norecCheck = false;
bool moneyCheck = false;
bool unlCheck = false;

bool isBypassed = false;



int testslide1 = 1337;
float testslide2 = 1488.0f;




bool setweaponbool;

int floatY = 15;

static int knifern = 0;
const char* knifetypes[] = {"Disable", "Karambit", "M9 Bayonet"};

static int karambitrn = 0;
const char* karambittype[] = { "None", "Dragon Glass","Gold", "Universe","Scratch", "Claw"};

static int m9rn = 0;
const char* m9type[] = { "None", "Dragon Glass","Ancient", "Universe","Scratch", "Blue Blood", "Digital Burst", "Kumo", "Frozen"};

char * idbuf = "72";
char * skinbuf = "72001";

float winalpha = 1.0f;


void AntiBan(){
	hexPatches.Aban1.Modify();
	hexPatches.Aban2.Modify();
	hexPatches.Aban3.Modify();
	hexPatches.Aban4.Modify();
	hexPatches.Aban5.Modify();
	hexPatches.Aban6.Modify();
}
/*
static GLuint fbo, texture1;

void checkStatesForGLDraw()
{
    if (openMenuuuu != lastopenmenu)
    {
        if (openMenuuuu)
        {
            glGenFramebuffers(2, &fbo);
            glGenTextures(2, &texture1);
            
            glBindTexture(GL_TEXTURE_2D, texture1);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 880, 660, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            
            glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, texture1, 0);
        }
        else
        {
            glDeleteFramebuffers(2, &fbo);
            glDeleteTextures(2, &texture1);
        }

        lastopenmenu = openMenuuuu;
    }
}
*/

void DrawMenu(){
    //checkStatesForGLDraw();
    
	if(openMenuuuu){
        ImGui::SetNextWindowSize(ImVec2(650, 425), ImGuiCond_Once);
		
		if(!ImGui::Begin(OBFUSCATE("@root_kalina 1"), NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar)){
		    ImGui::End();
		    return;
	    }
		
            ImVec2 P1, P2;
			ImDrawList* pDrawList;
			const auto& pCurrentWindowPos = ImGui::GetWindowPos();
			const auto& pWindowDrawList = ImGui::GetWindowDrawList();
			const auto& pBackgroundDrawList = ImGui::GetBackgroundDrawList();
			const auto& pForegroundDrawList = ImGui::GetForegroundDrawList();
	    	
			P1 = ImVec2(158.000f, 20.000f);
			P1.x += pCurrentWindowPos.x;
			P1.y += pCurrentWindowPos.y;
			P2 = ImVec2(160.000f, 405.000f);
			P2.x += pCurrentWindowPos.x;
			P2.y += pCurrentWindowPos.y;
			pDrawList = pWindowDrawList;
			pDrawList->AddRectFilledMultiColor(P1, P2,
			    ImColor(255, 255, 255, 255),
				ImColor(255, 255, 255, 255),
				ImColor(255, 255, 255, 255),
				ImColor(255, 255, 255, 255));
			
			
			ImVec2 Q1, Q2;
			ImDrawList* qDrawList;
			const auto& qCurrentWindowPos = ImGui::GetWindowPos();
			const auto& qWindowDrawList = ImGui::GetWindowDrawList();
			const auto& qBackgroundDrawList = ImGui::GetBackgroundDrawList();
			const auto& qForegroundDrawList = ImGui::GetForegroundDrawList();
	    	
			Q1 = ImVec2(35.000f, 68.000f);
			Q1.x += qCurrentWindowPos.x;
			Q1.y += qCurrentWindowPos.y;
			Q2 = ImVec2(125.000f, 70.000f);
			Q2.x += qCurrentWindowPos.x;
			Q2.y += qCurrentWindowPos.y;
			qDrawList = qWindowDrawList;
			qDrawList->AddRectFilledMultiColor(Q1, Q2,
			    ImColor(255, 255, 255, 255),
				ImColor(100, 100, 100, 255),
				ImColor(100, 100, 100, 255),
				ImColor(255, 255, 255, 255));
			
			
			ImGui::SetCursorPos(ImVec2(35, 35));
			ImGui::Text(OBFUSCATE("ASTERIAL"));
			
			ImGui::SetCursorPos(ImVec2(5, 100));
		    if (ImGui::Button(OBFUSCATE("Player"), ImVec2(150.0f, 40.0f))){
				
				page1 = true;
				page2 = false;
				page3 = false;
				page4 = false;
				page5 = false;
				
			}
			
			ImGui::SetCursorPos(ImVec2(5, 145));
		    if (ImGui::Button(OBFUSCATE("Visuals"), ImVec2(150.0f, 40.0f))){
				
				page1 = false;
				page2 = true;
				page3 = false;
				page4 = false;
				page5 = false;
				
			}
			
			ImGui::SetCursorPos(ImVec2(5, 190));
		    if (ImGui::Button(OBFUSCATE("Pokakal"), ImVec2(150.0f, 40.0f))){
				
				page1 = false;
				page2 = false;
				page3 = true;
				page4 = false;
				page5 = false;
				
			}
			
			ImGui::SetCursorPos(ImVec2(5, 235));
		    if (ImGui::Button(OBFUSCATE("Skins"), ImVec2(150.0f, 40.0f))){
				
				page1 = false;
				page2 = false;
				page3 = false;
				page4 = true;
				page5 = false;
				
			}
			
			ImGui::SetCursorPos(ImVec2(5, 280));
		    if (ImGui::Button(OBFUSCATE("Settings"), ImVec2(150.0f, 40.0f))){
				
				page1 = false;
				page2 = false;
				page3 = false;
				page4 = false;
				page5 = true;
				
			}
			
			
			
			if(page1){
				
				ImGui::SetCursorPos(ImVec2(165, 20));
				ImGui::BeginChild(1, ImVec2(480, 390), true);
				
				ImGui::Text("Menu by @root_kalina");
				ImGui::Spacing();
				ImGui::Text("Player menu");
				
				ImGui::EndChild();
				
			}
			
			
			if(page2){
				
				ImGui::SetCursorPos(ImVec2(165, 20));
				ImGui::BeginChild(1, ImVec2(480, 390), true);
				
				ImGui::Text("Menu by @root_kalina");
				ImGui::Spacing();
				ImGui::Text("Visuals menu");
				
				ImGui::EndChild();
				
			}
			
			
			if(page3){
				
				ImGui::SetCursorPos(ImVec2(165, 20));
				ImGui::BeginChild(1, ImVec2(480, 390), true);
				
				ImGui::Text("Menu by @root_kalina");
				ImGui::Spacing();
				ImGui::Text("Posral menu");
				
				ImGui::SliderInt("Int slider", &testslide1, 0, 9999);
				ImGui::SliderFloat("Float slider", &testslide2, 0, 9999);
				
				ImGui::EndChild();
				
			}
			
			
			if(page4){
				
				ImGui::SetCursorPos(ImVec2(165, 20));
				ImGui::BeginChild(1, ImVec2(480, 390), true);
				
				ImGui::Text("Menu by @root_kalina");
				ImGui::Spacing();
				ImGui::Text("Skins menu");
				
				ImGui::Text(OBFUSCATE("Legit skinchanger"));
				ImGui::Spacing();
				
				ImGui::Combo(OBFUSCATE("Knife"), &knifern, knifetypes, IM_ARRAYSIZE(knifetypes));
				
				if(knifern==1){
					ImGui::Combo(OBFUSCATE("Karambit"), &karambitrn, karambittype, IM_ARRAYSIZE(karambittype));
				}
				
				if(knifern==2){
					ImGui::Combo(OBFUSCATE("Bayonet M9"), &m9rn, m9type, IM_ARRAYSIZE(m9type));
				}
				
				ImGui::EndChild();
				
			}
			
			
			if(page5){
				
				ImGui::SetCursorPos(ImVec2(165, 20));
				ImGui::BeginChild(1, ImVec2(480, 390), true);
				
				ImGui::Text("Menu by @root_kalina");
				ImGui::Spacing();
				ImGui::Text("Settings menu");
				
				ImGui::EndChild();
				
			}
			
			
	} 
	ImGui::End();
}



void DrawOpen(){
	
	ImGui::SetNextWindowSize(ImVec2(100, 100), ImGuiCond_Once);
	
	    if(!ImGui::Begin(OBFUSCATE("@root_kalina"), NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar)){
		    ImGui::End();
		    return;
	    }
	
	
		
	if(ImGui::Button(OBFUSCATE("open"), ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetContentRegionAvail().y))) {
        openMenuuuu = !openMenuuuu;
    }
		
	ImGui::End();
}


void initInter()
{
  
  auto& Style = ImGui::GetStyle();
  
  Style.WindowBorderSize = 3.0f;

  Style.Colors[ImGuiCol_WindowBg] = ImVec4(0.03f, 0.03f, 0.03f, 1.0f);
  Style.Colors[ImGuiCol_ChildBg] = ImVec4(0.07f, 0.07f, 0.07f, 0.000f);
  Style.Colors[ImGuiCol_PopupBg] = ImVec4(0.07f, 0.07f, 0.07f, 0.940f);
  Style.Colors[ImGuiCol_Border] = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
  Style.Colors[ImGuiCol_FrameBg] = ImVec4(0.05f, 0.05f, 0.05f, 0.500f);
  Style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.07f, 0.07f, 0.07f, 0.750f);
  Style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.07f, 0.07f, 0.07f, 0.750f);
  Style.Colors[ImGuiCol_TitleBg] = ImVec4(0.525f, 0.000f, 0.522f, 1.000f);
  Style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.675f, 0.013f, 0.801f, 1.000f);
  Style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.300f, 0.009f, 0.343f, 0.232f);
  Style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.4f, 0.4f, 0.4f, 0.500f);
  Style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.020f, 0.020f, 0.020f, 0.000f);
  Style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.25f, 0.25f, 0.25f, 0.500f);
  Style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.33f, 0.33f, 0.33f, 0.750f);
  Style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.33f, 0.33f, 0.33f, 0.750f);
  Style.Colors[ImGuiCol_CheckMark] = ImColor(255, 0, 255, 255);
  Style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.25f, 0.25f, 0.25f, 0.500f);
  Style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.33f, 0.33f, 0.33f, 0.750f);
  Style.Colors[ImGuiCol_Button] = ImVec4(0.07f, 0.07f, 0.07f, 0.500f);
  Style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.1f, 0.1f, 0.1f, 0.750f);
  Style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.1f, 0.1f, 0.1f, 0.750f);
  Style.Colors[ImGuiCol_Header] = ImVec4(0.03f, 0.03f, 0.03f, 1.0f);
  Style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.03f, 0.03f, 0.03f, 1.0f);
  Style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.03f, 0.03f, 0.03f, 1.0f);
  Style.Colors[ImGuiCol_Separator] = ImColor(255, 0, 255, 255);
  Style.Colors[ImGuiCol_SeparatorHovered] = ImColor(255, 0, 255, 255);
  Style.Colors[ImGuiCol_SeparatorActive] = ImColor(255, 0, 255, 255);
  Style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.25f, 0.25f, 0.25f, 0.500f);
  Style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.33f, 0.33f, 0.33f, 0.750f);
  Style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.33f, 0.33f, 0.33f, 0.750f);
  Style.Colors[ImGuiCol_Tab] = ImVec4(0.446f, 0.167f, 0.464f, 0.862f);
  Style.Colors[ImGuiCol_TabHovered] = ImVec4(0.680f, 0.222f, 0.647f, 0.800f);
  Style.Colors[ImGuiCol_TabActive] = ImVec4(0.807f, 0.263f, 0.786f, 1.000f);
  Style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.236f, 0.122f, 0.276f, 0.972f);
  Style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.424f, 0.136f, 0.346f, 1.000f);
  Style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.4f, 0.4f, 0.4f, 0.5f);
  Style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.4f, 0.4f, 0.4f, 0.5f);

  //Style.Colors[ImGuiCol_WindowBg] = ImVec4(0.376f, 0.050f, 0.352f, 0.940f);
  //Style.Colors[ImGuiCol_CheckMark] = ImVec4(1.000f, 0.000f, 0.895f, 1.000f);
}



#define HOOKAF(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOKAF(void, Input, void *thiz, void *ex_ab, void *ex_ac) {
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}

void SetupImgui() {
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);

    // Setup Dear ImGui style
    // Setup Platform/Renderer backends
    ImGui_ImplOpenGL3_Init("#version 100");
	
	initInter();

    // We load the default font with increased size to improve readability on many devices with "high" DPI.
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontDefault(&font_cfg);

    // Arbitrary scale-up
    ImGui::GetStyle().ScaleAllSizes(scaleEz);
}



int (*get_WeaponId)(void* player);

void (*old_gunUpdate)(void* player);
void gunUpdate(void* a) {
    //ammoFunctions(a);
    old_gunUpdate(a);
}
void (*old_gunUpdate1)(void* player);
void gunUpdate1(void* a) {
    //ammoFunctions(a);
    old_gunUpdate1(a);
}
void (*old_gunUpdate2)(void* player);
void gunUpdate2(void* a) {
    //ammoFunctions(a);
    old_gunUpdate2(a);
}
void (*old_gunUpdate3)(void* player);
void gunUpdate3(void* a) {
    //ammoFunctions(a);
    old_gunUpdate3(a);
}

void (*old_gunUpdate4)(void* player);
void gunUpdate4(void* a) {
    //ammoFunctions(a);
    old_gunUpdate4(a);
}

void (*old_gunUpdate5)(void* player);
void gunUpdate5(void* a) {
    //ammoFunctions(a);
    old_gunUpdate5(a);
}

void (*old_gunUpdate6)(void* player);
void gunUpdate6(void* a) {
    //ammoFunctions(a);
    old_gunUpdate6(a);
}

int weaponid;

void (*SetWeapon)(void* player, int WeaponId);
void (*old_GameUpdate)(void* instance);
void GameUpdate(void* instance) {
     if (setweaponbool) {
      SetWeapon(instance, weaponid);
     }
    old_GameUpdate(instance);
}






struct IdWeapin0231 {
    int None = 0;
    int G22 = 11;
    int USP = 12;
    int P350 = 13;
    int Deagle = 15;
    int Tec9 = 16;
    int FiveSeven = 17;
    int UMP45 = 32;
    int MP7 = 34;
    int P90 = 35;
    int MP5 = 36;
    int MAC10 = 37;
    int M4A1 = 43;
    int AKR = 44;
    int AKR12 = 45;
    int M4 = 46;
    int M16 = 47;
    int FAMAS = 48;
    int FnFal = 49;
    int AWM = 51;
    int M40 = 52;
    int M110 = 53;
    int SM1014 = 62;
    int FabM = 63;
    int M60 = 64;
    int SPAS = 65;
    int Knife = 70;
    int KnifeBayonet = 71;
    int KnifeKarambit = 72;
    int jKommando = 73;
    int KnifeButterfly = 75;
    int FlipKnife = 77;
    int KunaiKnife = 78;
    int ScorpionKnife = 79;
    int KnifeTanto = 80;
    int DaggerKnife = 81;
    int KnifeKukri = 82;
	int KnifeStilet = 83;
    int GrenadeHE = 91;
    int GrenadeSmoke = 92;
    int GrenadeFlash = 93;
    int Bomb = 100;
    int Defuser = 101;
    int DefuseKit = 102;
    int Vest = 110;
    int VestAndHelmet = 111;
    int Watergun = 19;
    int GrenadeSnowball = 99;
    int CandyCane = 84;
    int Minigun = 41;
    int ZombieHands = 83;
    } idweap;
    
    
int (*old_EquipedKnife)(void *instance);
int EquipedKnife(void *instance) {

    if (knifern == 0) { 
    return 70; //default
    } else if (knifern == 1) {
    return 72; //karambit
    } else if (knifern == 2) {
    return 71; //m9
    }
    return old_EquipedKnife(instance);
}

int weaponId = 70;

int (*old_EquipedSkin)(void *instance, int weaponId);
int EquipedSkin(void *instance, int weaponId) {
    if (knifern == 2 && weaponId == 71) {
        int returns = 0;
        if(m9rn == 0){
        returns = 220022;
        }
        if(m9rn == 1){
        returns = 71005;
        }
        if(m9rn == 2){
        returns = 71002;
        }
        if(m9rn == 3){
        returns = 71004;
        }
        if(m9rn == 4){
        returns = 71003;
        }
        if(m9rn == 5){
        returns = 71001;
        }             
        if(m9rn == 6){
        returns = 200012;
        }
        if(m9rn == 7){
        returns = 157100;
        }
        if(m9rn == 8){
        returns = 97100;
        }
        return returns;
    } else if (knifern == 1 && weaponId == 72) {
        int returns = 0;
        if(karambitrn == 0){
        returns = 220022;
        }
        if(karambitrn == 1){
        returns = 72004;
        }
        if(karambitrn == 2){
        returns = 72003;
        }
        if(karambitrn == 3){
        returns = 72007;
        }
        if(karambitrn == 4){
        returns = 72006;
        }
        if(karambitrn == 5){
        returns = 72002;
        }          
        return returns;
    } 
	return old_EquipedSkin(instance, weaponId);
}






EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);

    if (!setup) {
        SetupImgui();
        setup = true;
    }

    ImGuiIO &io = ImGui::GetIO();


    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    DrawOpen();
    DrawMenu();
	
	//PostProcessing::newFrame();
	
	//PostProcessing::performFullscreenBlur(pDrawList, 0.7f);
	
	AntiBan();
    ImGui::EndFrame();
    ImGui::Render();
	hexPatches.ChamsBypass.Modify();
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());


    return old_eglSwapBuffers(dpy, surface);
}

monoString*GetPlayerWeapon(void*a) {
    auto w1 = *(void **) ((uint64_t) a + 0x34);    if (w1) {
        auto w2 = *(void **) ((uint64_t) w1 + 0x50);        if (w2) {
            auto w3 = *(void **) ((uint64_t) w2 + 0x3C);            if (w3) {
                auto w4 = *(monoString **) ((uint64_t) w3 + 0x10);                if (w4) return w4;
            }        }
    }}

void threadhooks() {
	//DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x1440FE8"))), (void *) PlayerController, (void **) &old_PlayerController);
	
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x31A1AC0"))), (void *) gunUpdate, (void **) &old_gunUpdate);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x319DD5C"))), (void *) gunUpdate1, (void **) &old_gunUpdate1);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x3199F38"))), (void *) gunUpdate2, (void **) &old_gunUpdate2);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x319A2AC"))), (void *) gunUpdate3, (void **) &old_gunUpdate3);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x319B77C"))), (void *) gunUpdate4, (void **) &old_gunUpdate4);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x319C694"))), (void *) gunUpdate5, (void **) &old_gunUpdate5);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x319B524"))), (void *) gunUpdate6, (void **) &old_gunUpdate6);
	
	DobbyHook((void *) KittyMemory::getAbsoluteAddress(OBFUSCATE("libunity.so"), string2Offset(OBFUSCATE("0xC2DEF4"))), (void *) GameUpdate, (void **) &old_GameUpdate);
	
	
	
    //hexs
    hexPatches.ChamsBypass = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x20B5A88")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Clumsy = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x29CFC74")), OBFUSCATE("00 00 00 00"));

	hexPatches.Aban1 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x247811C")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban2 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x24784E8")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban3 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x24768B0")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban4 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x2476C34")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban5 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x247741C")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban6 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x2477618")), OBFUSCATE("1E FF 2F E1"));
}

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {
        sleep(1);
    } while (!isLibraryLoaded("libil2cpp.so"));
    //init shaders
    setShader(OBFUSCATE("_BumpMap"));
    mlovinit();
    LogShaders();
    Wallhack();
    threadhooks();
    pthread_exit(nullptr);
    return nullptr;
	
	DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x2F4ED6C"))), (void*)EquipedSkin, (void**)&old_EquipedSkin);
    DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x2F51924"))), (void*)EquipedKnife, (void**)&old_EquipedKnife);
    //DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x87FF70"))), (void*)setGloves, (void**)&old_setGloves);


	
}

void *imgui_go(void *) {
    address = findLibrary("libil2cpp.so");
    auto addr = (uintptr_t)dlsym(RTLD_NEXT, "eglSwapBuffers");
    DobbyHook((void *)addr, (void *)hook_eglSwapBuffers, (void **)&old_eglSwapBuffers);
    pthread_exit(nullptr);
    return nullptr;
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
	    void *sym_input = DobbySymbolResolver(("/system/lib/libinput.so"), ("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE"));
    if (NULL != sym_input) {
        DobbyHook((void *)sym_input, (void *) myInput, (void **)&origInput);
    }
    DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x1B0736C"))), (void *) touches, (void **) &old_touches);
    pthread_t ptid;
    pthread_create(&ptid, NULL, imgui_go, NULL);
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL);
}



