/*
 * ulong positionoffset = string2Offset(OBFUSCATE("0x2721C04"));
ulong transformoffset = string2Offset(OBFUSCATE("0x2712464"));
ulong plpositionoffset = string2Offset(OBFUSCATE("0x2721B88"));
ulong rotationoffset = string2Offset(OBFUSCATE("0x2722018"));
ulong getcameraoffset = string2Offset(OBFUSCATE("0x26E8E68"));
ulong getbipedmapoffset = string2Offset(OBFUSCATE("0x1441064"));//0x1441064
ulong islocaloffset = string2Offset(OBFUSCATE("0x292AFC8"));
ulong setpositioninj = string2Offset(OBFUSCATE("0x2721CB4"));
ulong setposition = string2Offset(OBFUSCATE("0x2721CB4"));
ulong worldtoscrinj = string2Offset(OBFUSCATE("0x26E824C"));
ulong getplayerteam = string2Offset(OBFUSCATE("0x1440914"));//0xF6B774;
ulong getplayerhealth = string2Offset(OBFUSCATE("0x1439D10"));
ulong gettimeoffset = string2Offset(OBFUSCATE("0x26ED210"));
ulong joystickaxis = string2Offset(OBFUSCATE("0x201DD40"));
ulong castbulletoff = string2Offset(OBFUSCATE("0x31921EC"));
ulong cameraupdate = string2Offset(OBFUSCATE("0xFF2B10"));
ulong pingoffset = string2Offset(OBFUSCATE("0x2923480"));
ulong playercontroller = string2Offset(OBFUSCATE(""));
ulong autowincto = string2Offset(OBFUSCATE("0xF71BB8"));
ulong gu0 = string2Offset(OBFUSCATE("0x31A1AC0"));
ulong gu1 = string2Offset(OBFUSCATE("0x319DD5C"));
ulong gu2 = string2Offset(OBFUSCATE("0x3199F38"));
ulong gu3 = string2Offset(OBFUSCATE("0x319A2AC"));
ulong gu4 = string2Offset(OBFUSCATE("0x319B77C"));
ulong gu5 = string2Offset(OBFUSCATE("0x319C694"));
ulong gu6 = string2Offset(OBFUSCATE("0x319B524"));
ulong equippedskin = string2Offset(OBFUSCATE("0x2FBED44"));
ulong timestamp = string2Offset(OBFUSCATE("0x291AF04"));
ulong equippedknife = string2Offset(OBFUSCATE("0x2FC2C10"));
ulong settps = string2Offset(OBFUSCATE("0x143B824"));
ulong knifecontr = string2Offset(OBFUSCATE("0x2FB776C"));
ulong hitinn = string2Offset(OBFUSCATE("0x2FB780C"));
ulong getespteam = string2Offset(OBFUSCATE("0xF6B774"));
 */


//structs
struct My_Patches {
    MemoryPatch Clumsy, ChamsBypass, Aban1, Aban2, Aban3, Aban4, Aban5, Aban6;}
hexPatches;

//legit
bool airjump;

//visuals
bool nightbool;
bool handspos;
int handsX, handsY, handsZ = 0;

//hooks
void *ptr;
void* enemy = nullptr;
void *me = nullptr;
void *team = nullptr;

void *(*get_camera)();

bool (*IsLocal)(void* player);
static void *get_photon(void *player) {
    return *(void **)((uint64_t) player + 0xA8);
}
float (*get_deltaTime)();

void (*old_PlayerController)(void* player);
void PlayerController(void* player) {
    if (player) {
        if (!ptr)
            ptr = * (void **)((uint64_t) player + 0xA8);
    }
    if (player != nullptr){
        if (IsLocal(get_photon(player))) {
            me = player;
        }
        if (me){
            if (handspos) {
                void *arms = *(void **) ((uint64_t) player + 0x40);
                if (arms) {
                    *(Vector3 *) ((uint64_t) arms + 0x94) =
                            Vector3(handsX, handsY, handsZ) / 50;
                    *(bool *) ((uint64_t) arms + 0x44) = !handspos;
                }
            }
        }
    }
    return old_PlayerController(player);
}

bool (*old_air_jump_system_general)(void* inst);
bool air_jump_system(void* inst){
    if (airjump){
        return true;
    }
    return old_air_jump_system_general(inst);
}

int (*old_touches)(void *instance);
int touches(void* instance){
    ImGuiIO& io = ImGui::GetIO();
    if (io.WantCaptureMouse) {
        return 0;
    }
    return old_touches(instance);
}
