#pragma once

struct ImDrawList;

namespace PostProcessing
{
	void newFrame() noexcept;
    void performFullscreenBlur(ImDrawList* drawList, float alpha) noexcept;
    void performFullscreenChromaticAberration(ImDrawList* drawList, float amount) noexcept;
    void performFullscreenMonochrome(ImDrawList* drawList, float amount) noexcept;
}
